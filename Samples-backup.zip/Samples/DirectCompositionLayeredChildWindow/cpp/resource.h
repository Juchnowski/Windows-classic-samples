// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DirectComposition_LayeredChildWindow.rc
//

#define IDS_FONT_TYPEFACE				101
#define IDS_FONT_HEIGHT_LOGO			102
#define IDS_FONT_HEIGHT_TITLE			103
#define IDS_FONT_HEIGHT_DESCRIPTION		104

// Next default values for new objects
// 
#ifdef  APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
